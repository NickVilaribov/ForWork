$(function() {
 
});

$(window).on('load', function() {
  $('.animation').delay(1000).fadeOut('slow');
});

